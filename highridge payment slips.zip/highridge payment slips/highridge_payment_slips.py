import random

# Generate workers
workers = []
names = ["John", "Alice", "Bob", "Sarah", "Michael", "Emily", "David", "Sophia"]

for i in range(400):
    name = random.choice(names) + f"_{i+1}"
    salary = random.randint(5000, 35000)
    gender = random.choice(["Male", "Female"])
    workers.append({"name": name, "salary": salary, "gender": gender})

# Generate payment slips
for worker in workers:
    try:
        if 10000 < worker["salary"] < 20000:
            employee_level = "A1"
        elif 7500 < worker["salary"] < 30000 and worker["gender"] == "Female":
            employee_level = "A5-F"
        else:
            employee_level = "B1"

        print(f"Payment Slip for {worker['name']} (Level: {employee_level}):")
        print(f"Salary: ${worker['salary']}")
        print(f"Employee Level: {employee_level}\n")

    except KeyError as e:
        print(f"KeyError: Missing {e} for worker {worker['name']}")
    except Exception as e:
        print(f"Error: {str(e)} for worker {worker['name']}")
