
set.seed(123)


workers <- list()
generate_workers <- function(num_workers = 400) {
  names <- c("John", "Alice", "Bob", "Sarah", "Michael", "Emily", "David", "Sophia")
  
  for (i in 1:num_workers) {
    name <- paste0(sample(names, 1), "_", i)
    salary <- sample(5000:35000, 1)
    gender <- sample(c("Male", "Female"), 1)
    workers[[i]] <<- list(name = name, salary = salary, gender = gender)  # use <<- to modify global list
  }
}


generate_workers()


generate_payment_slips <- function() {
  for (worker in workers) {
    tryCatch({
      
      if (worker$salary > 10000 && worker$salary < 20000) {
        employee_level <- "A1"
      } else if (worker$salary > 7500 && worker$salary < 30000 && worker$gender == "Female") {
        employee_level <- "A5-F"
      } else {
        employee_level <- "B1"
      }
      
     
      cat(sprintf("Payment Slip for %s (Level: %s):\n", worker$name, employee_level))
      cat(sprintf("Salary: $%d\n", worker$salary))
      cat(sprintf("Employee Level: %s\n\n", employee_level))
      
    }, error = function(e) {
      cat(sprintf("Error: %s for worker %s\n", e$message, worker$name))
    })
  }
}


generate_payment_slips()
