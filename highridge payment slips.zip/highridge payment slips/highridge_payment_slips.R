set.seed(123)  
# Generate workers
workers <- list()
names <- c("John", "Alice", "Bob", "Sarah", "Michael", "Emily", "David", "Sophia")

for (i in 1:400) {
  name <- paste0(sample(names, 1), "_", i)
  salary <- sample(5000:35000, 1)
  gender <- sample(c("Male", "Female"), 1)
  workers[[i]] <- list(name = name, salary = salary, gender = gender)
}

# Generate payment slips
for (worker in workers) {
  tryCatch({
    if (worker$salary > 10000 && worker$salary < 20000) {
      employee_level <- "A1"
    } else if (worker$salary > 7500 && worker$salary < 30000 && worker$gender == "Female") {
      employee_level <- "A5-F"
    } else {
      employee_level <- "B1"
    }

    cat("Payment Slip for", worker$name, "(Level:", employee_level, "):\n")
    cat("Salary: $", worker$salary, "\n")
    cat("Employee Level:", employee_level, "\n\n")
    
  }, error = function(e) {
    cat("Error:", e$message, "for worker", worker$name, "\n")
  })
}
