 Highridge Construction - Payment Slips

This project generates weekly payment slips for 400 workers using Python and R.

 Files
- `highridge_payment_slips.py` – Python version
- `highridge_payment_slips.R` – R version
- `README.md` – Instructions

 How to Run

 Python
1. Make sure Python is installed.
2. Run:
```bash
python highridge_payment_slips.py
